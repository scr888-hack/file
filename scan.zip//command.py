



#========= บรอดแคส Template ทุกกลุ่ม ==============

                elif text.lower() == "//เตือน" or text.lower() == "/เตือน":
                          groups = line.getGroupIdsJoined()
                          for group in groups:
                            data = {
                                "type": "template",
                                "altText": "⚜️⚜️  เพจอันตรายห้ามเล่น ⚜️⚜️\n อัพเดต By.SLOT THAI ️",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl":"https://www.img.in.th/images/751a1c5fdf28c3465c6c1c19473ce49c.jpg",
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri":"https://www.img.in.th/images/748c8477e2a64092846697af47959274.jpg"
                                            }
                                        }
                                    ]
                                }
                            }
                            {
                                "type": "template",
                                "altText": "⚜️⚜️  เพจอันตรายห้ามเล่น ⚜️⚜️\n อัพเดต By.SLOT THAI ️",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "url":"https://www.img.in.th/images/662c1a276c20294052c79dfe65bdde94.jpg",
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri":"https://www.img.in.th/images/748c8477e2a64092846697af47959274.jpg"
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(group, data)
#========= บรอดแคส Template ไปแชทส่วนตัวเพื่อนทุกคน ==============

                if text.lower() == "Allscanwin" or text.lower() == ".อัพเดต":
                          gid = line.getAllContactIds()
                          for i in gid:
                            dataProfile = [
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor":"#000000"},
                                        "hero": {"backgroundColor": "#000000"}, #"separator": True, "separatorColor": "#333333"},
                                        "footer": {"backgroundColor": "#FF0000"}, #"separator": True, "separatorColor": "#333333"}
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "xxl",
                                        "contents": [
                                            {
                                                "type":"image",
                                                "url":"https://data.bloggif.com/distant/user/store/2/9/a/1/b1811c978876e890d6cc2ee86d261a92.gif",
                                                "aspectMode":"cover",
                                                "margin":"xxl",
                                                "aspectRatio":"16:25",
                                                "size":"full",
                                                "action":{
                                                    "type":"uri",
                                                    "uri":"https://lin.ee/sVQoXGF"
                                                 },
                                            },
                                        ]
                                    },
                                },
                            ]
                            data = {
                                "type": "flex",
                                "altText": "⚜️⚜️ แจ้งข่าวสาร อัพเดตเพจโกง ⚜️⚜️",
                                "contents": {
                                    "type": "carousel",
                                    "contents": dataProfile
                                }
                            }
                            sendTemplate(i, data)
#========= บรอดแคส ข้อความธรรมดา ทุกกลุ่ม ==============

                elif msg.text.lower().startswith("#gbc: "):
                    sep = text.split(" ")
                    text_ = text.replace(sep[0] + " ","")
                    groups = line.groups
                    for group in groups:
                        line.sendMessage(group, "{}".format(str(text_)))
                    else:
                        line.sendMessage(to, "ส่งแล้ว ทั้งหมด {} กลุ่ม".format(str(len(groups))))
#========= บรอดแคส ข้อความธรรมดา ทุกแชทของเพื่อน ==============

                elif msg.text.lower().startswith("#gbc: "):
                    sep = text.split(" ")
                    text_ = text.replace(sep[0] + " ","")
                    gid = line.getAllContactIds()
                    for i in gid:
                        line.sendMessage(i, "{}".format(str(text_)))
                    else:
                        line.sendMessage(to, "ส่งแล้ว ทั้งหมด {} คน".format(str(len(i))))
#=====================================================================

